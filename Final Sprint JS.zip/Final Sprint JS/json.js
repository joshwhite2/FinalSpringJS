
//GET TODAY'S DATE
const today = new Date()
val = today.getFullYear()


//FETCH and READ the .json disk files
fetch(`./Cast List.json`)
    .then(response => response.json())
    .then(data => {

    data.forEach(person => {
      
        console.log(getfullname(person))
        console.log(getfullsentence(person))
        console.log(getbirthyear(person))  
    })


    function getStatus(person){
        return person.status;     
    };


    function getAge(person){
        return person.age;
    };


    function getfullname(person){
        return `${person.fname} ${person.lname}`;
    };

    function getbirthyear(person){
        return `Birth Year: ${val - person.age}`;
    };

    function getfullsentence(person){
        return `${person.fname} is ${person.age} years old and is ${person.status}. They play ${person.character} and make ${person.salary} a year`;
    };
    
   html= `${data[0].fname} ${data[0].lname} created the sitcom ${data[0].lname} in the late 80s. The show consists of ${data[0].lname} and his three friends; ${data[1].character}, ${data[2].character}, and ${data[3].character}, living in New York while exploring and highlighting many awkward social norms. Often visited and annoyed by his neighbour ${data[3].character}, who often cook up hair brained schemes to pull off with Jerry's nemisis, ${data[4].character}, these two can create a great deal of headaches for ${data[0].fname}!` ;
  
   document.body.innerHTML = html;
})
